import string
import nltk
from nltk import word_tokenize, pos_tag 
import re
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
from chatterbot.trainers import ChatterBotCorpusTrainer
import json
import urllib
from bs4 import BeautifulSoup
import requests
from ftplib import FTP
from StringIO import StringIO
import csv


bot = ChatBot('Test')
bot.set_trainer(ListTrainer)
q_word = ['what', 'where', 'who', 'when', 'how']
filler_word = ['of', 'and', 'is','be', 'are', 'was', 'were', 'you', 'the']
info_word = ['stock', 'price', 'netincome', 'assets', 'liabilities','equity','cashflow','10-k','10-q','income']

learned_list = []
info_list =[]
while True: 
    found = False
    comp_list=[]
    keyword=[]
    user_input = raw_input('how can I help you? ')
    for learned in learned_list:
        if (user_input == learned):
            out = bot.get_response(user_input)
            print out
            found = True
            break
    
    if found:
        continue

    word_list = re.sub("[^\w]", " ", user_input).split()
    #print word_list
    new_list = []       
    for word in word_list:
        if word not in q_word and word not in filler_word and word not in learned_list and word not in info_word:
            new_list.append(word)
        elif word in info_word:
            info_list.append(word)
        elif word in learned_list:
            keyword.append(word)
     
    #print info_list
    #print new_list
    #print keyword
    com_name = ' '.join(new_list)
    #print com_name
    com_name_url = '+'.join(new_list)
    #print com_name_url
    url = "http://api.corpwatch.org/2008/companies.json?company_name=" + com_name_url + "&key=a67703dfa63f371dc1520e9260336274"
    link =  urllib.urlopen(url)
    data = json.load(link) 
    #data = data['result']['companies']
    for cw in data['result']['companies'].keys():
        comp_list.append((data['result']['companies'][cw]['company_name'], cw, data['result']['companies'][cw]['cik'] ))
    
    confirmed_comp = None
    for comps in comp_list:
        confirm = raw_input('Do you mean '+comps[0]+': ')
        if confirm == "yes":
            confirmed_com = comps
            break

    search_type = '10-q'
    keyword.append(confirmed_com[0])
    cik = confirmed_com[2]
    
    src = 'https://www.sec.gov/cgi-bin/browse-edgar?CIK=%s&action=getcompany&type=%s'%(cik,search_type)
    r = urllib.urlopen(src).read()
    #print src
    source_code = requests.get(src)
    plain_text = source_code.text
    soup = BeautifulSoup(plain_text,'html.parser')
    acc = None
    for td_str in soup.find_all('td',class_="small"):
        if not acc:
            acc=''.join(td_str.findAll(text=True))
        else:
            break
    
    #print acc

    regex = r"(\d{10}-\d{2}-\d{6})"
    match = re.search(regex, acc)

    acc_code = match.group(0)
    #print acc_code
 
    ftp_link = 'ftp://ftp.sec.gov/edgar/data/'+cik+'/'+acc_code+'.txt'
    #print ftp_link

    
    #urllib.urlretrieve(ftp_link, 'table.html')
    
    answer = ''
    str_var=''
    info_table  = None
    for word in info_list:
        if word == 'netincome':
            soup = BeautifulSoup(open("table.html"), 'html.parser')
            for tr_str in soup.findAll('font',style="font-size:10.0pt;"):
                str_var=''.join(tr_str.findAll(text=True))
                
                str_var = str_var.replace('\n',' ')
                str_var = str_var.replace('\r','')
                #str_var = str_var.replace('style=\"margin:0in;margin-bottom:.0001pt;page-break-after:avoid;\"',' ')
                str_list = re.sub("[^\w]", " ", str_var).split()
                if str_list:
                    sout =''
                    count = 0
                    #for ele in str_list:
                        #if count<4:
                            #sout=sout+ele
                            #count=count+1
                            #break
                    #print str_list[0]
                    #answer = sout #+' '+sout[1] +' of '+ confirmed_com[0] + ' is: $' + sout[2]+','+sout[3]
                    #print answer
                    #print str_list
                    
        elif word == 'assets':
            #info_table = ('table1.html', word)
            soup = BeautifulSoup(open("table1.html"), 'html.parser')
            for tr_str in soup.findAll('font',style="font-size:10.0pt;"):
                str_var=''.join(tr_str.findAll(text=True))
                str_var = str_var.replace('\n',' ')
                str_var = str_var.replace('\r','')
                str_var = str_var.replace('style=\"margin:0in;margin-bottom:.0001pt;page-break-after:avoid;\"',' ')
                str_list = re.sub("[^\w]", " ", str_var).split()
                if str_list:
                    print str_list                   
        elif word == 'liabilities' or word == 'equity':
            #info_table = ('table1.html', word)
            soup = BeautifulSoup(open("table2.html"), 'html.parser')
            for tr_str in soup.findAll('font',style="font-size:10.0pt;"):
                str_var=''.join(tr_str.findAll(text=True))
                str_var = str_var.replace('\n',' ')
                str_var = str_var.replace('\r','')
                str_var = str_var.replace('style=\"margin:0in;margin-bottom:.0001pt;page-break-after:avoid;\"',' ')
                str_list = re.sub("[^\w]", " ", str_var).split()
                if str_list:
                    print str_list
        elif word == 'cashflow':
            #info_table = ('table1.html', word)
            soup = BeautifulSoup(open("table3.html"), 'html.parser')
            for tr_str in soup.findAll('font',style="font-size:10.0pt;"):
                str_var=''.join(tr_str.findAll(text=True))
                str_var = str_var.replace('\n',' ')
                str_var = str_var.replace('\r','')
                str_var = str_var.replace('style=\"margin:0in;margin-bottom:.0001pt;page-break-after:avoid;\"',' ')
                str_list = re.sub("[^\w]", " ", str_var).split()
                if str_list:
                    print str_list

        
    #soup = BeautifulSoup(open(info_table[0]), 'html.parser')
    
    

    if not keyword:
        print 'no company'
    else:
        #url = "http://api.corpwatch.org/2008/companies.json?cik=789019&key=a67703dfa63f371dc1520e9260336274"
        #link = urllib.urlopen(url)
        #data = json.load(link)
        #print data
        keystring = ' '.join(keyword)
        response = keystring + ': '+ftp_link
        bot.train([user_input, response])
        learned_list.append(user_input)
        out = bot.get_response(user_input)
        print out

    

