# FintechHackathon

#This Project is still incomplete.

The idea is to create a bot that can scrape the edgar db and provide user information about financial question.

As of now all we have is a python file that is being used to give users links to the 10-K and 10-Q.

But we have plans for getting the project up in a heroku server.
